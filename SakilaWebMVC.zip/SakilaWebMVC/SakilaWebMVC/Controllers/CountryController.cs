﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using SakilaWebMVC.Models;

namespace SakilaWebMVC.Controllers
{
    public class CountryController : Controller
    {
        private readonly string _connectionString;

        // 1. Inyección de la cadena de conexión desde appsettings.json
        public CountryController(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("SakilaConnection");
        }

        // 2. LECTURA (Index)
        public IActionResult Index()
        {
            List<Country> countries = new List<Country>();
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                // Ordenamos por country_id descendente para ver los agregados recientemente
                string query = "SELECT country_id, country FROM country ORDER BY country_id DESC";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    con.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            countries.Add(new Country
                            {
                                CountryId = Convert.ToInt16(reader["country_id"]),
                                CountryName = reader["country"].ToString()
                            });
                        }
                    }
                }
            }
            return View(countries);
        }

        // 3. CREACIÓN (GET)
        public IActionResult Create()
        {
            return View();
        }

        // 4. CREACIÓN (POST) con consulta parametrizada
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Country model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                // Inyectamos GETDATE() para cumplir con la columna last_update de Sakila
                string query = "INSERT INTO country (country, last_update) VALUES (@country, GETDATE())";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@country", model.CountryName);
                    con.Open();
                    cmd.ExecuteNonQuery();
                }
            }
            return RedirectToAction(nameof(Index));
        }
        // 5. DETALLES (GET)
        public IActionResult Details(short? id)
        {
            if (id == null) return NotFound();

            Country country = new Country();
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                string query = "SELECT country_id, country FROM country WHERE country_id = @id";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    con.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            country.CountryId = Convert.ToInt16(reader["country_id"]);
                            country.CountryName = reader["country"].ToString();
                        }
                        else return NotFound();
                    }
                }
            }
            return View(country);
        }

        // 6. EDITAR (GET)
        public IActionResult Edit(short? id)
        {
            if (id == null) return NotFound();

            Country country = new Country();
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                string query = "SELECT country_id, country FROM country WHERE country_id = @id";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    con.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            country.CountryId = Convert.ToInt16(reader["country_id"]);
                            country.CountryName = reader["country"].ToString();
                        }
                        else return NotFound();
                    }
                }
            }
            return View(country);
        }

        // 7. EDITAR (POST)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(short id, Country model)
        {
            if (id != model.CountryId) return NotFound();

            if (!ModelState.IsValid) return View(model);

            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                string query = "UPDATE country SET country = @country, last_update = GETDATE() WHERE country_id = @id";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@country", model.CountryName);
                    cmd.Parameters.AddWithValue("@id", model.CountryId);
                    con.Open();
                    cmd.ExecuteNonQuery();
                }
            }
            return RedirectToAction(nameof(Index));
        }

        // 8. ELIMINAR (GET)
        public IActionResult Delete(short? id)
        {
            if (id == null) return NotFound();

            Country country = new Country();
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                string query = "SELECT country_id, country FROM country WHERE country_id = @id";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    con.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            country.CountryId = Convert.ToInt16(reader["country_id"]);
                            country.CountryName = reader["country"].ToString();
                        }
                        else return NotFound();
                    }
                }
            }
            return View(country);
        }

        // 9. ELIMINAR (POST) - Aquí cumplimos el Requerimiento 12
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(short id)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    string query = "DELETE FROM country WHERE country_id = @id";
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            catch (SqlException ex)
            {
                // Si SQL Server lanza error por la clave foránea con City, lo capturamos aquí
                TempData["ErrorMessage"] = "Integridad Referencial: No se puede eliminar este país porque tiene ciudades asociadas en la base de datos.";
                return RedirectToAction(nameof(Delete), new { id = id });
            }
        }
    }
}