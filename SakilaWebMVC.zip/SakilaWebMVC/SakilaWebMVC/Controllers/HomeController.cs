using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;

namespace SakilaWebMVC.Controllers
{
    public class HomeController : Controller
    {
        private readonly string _connectionString;

        public HomeController(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("SakilaConnection");
        }

        public IActionResult Index()
        {
            int cantidadPaises = 0;
            int cantidadCiudades = 0;

            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                con.Open();

                // Contar Países
                using (SqlCommand cmdPaises = new SqlCommand("SELECT COUNT(*) FROM country;", con))
                {
                    cantidadPaises = (int)cmdPaises.ExecuteScalar();
                }

                // Contar Ciudades
                using (SqlCommand cmdCiudades = new SqlCommand("SELECT COUNT(*) FROM city;", con))
                {
                    cantidadCiudades = (int)cmdCiudades.ExecuteScalar();
                }
            }

            ViewBag.CantidadPaises = cantidadPaises;
            ViewBag.CantidadCiudades = cantidadCiudades;

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }
    }
}