﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.SqlClient;
using SakilaWebMVC.Models;

namespace SakilaWebMVC.Controllers
{
    public class CityController : Controller
    {
        private readonly string _connectionString;

        public CityController(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("SakilaConnection");
        }

        // Método auxiliar para cargar la lista de países en el dropdown (Requerimiento 11)
        private void CargarPaises()
        {
            List<SelectListItem> paises = new List<SelectListItem>();
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                string query = "SELECT country_id, country FROM country ORDER BY country";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    con.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            paises.Add(new SelectListItem
                            {
                                Value = reader["country_id"].ToString(),
                                Text = reader["country"].ToString()
                            });
                        }
                    }
                }
            }
            // Usamos ViewBag para pasar la lista a la vista
            ViewBag.Paises = paises;
        }

        // 1. LECTURA (Index) con INNER JOIN (Requerimiento 10)
        public IActionResult Index()
        {
            List<City> cities = new List<City>();
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                // El INNER JOIN clave para traer el nombre del país
                string query = @"
                    SELECT 
                        ci.city_id, 
                        ci.city, 
                        ci.country_id, 
                        co.country 
                    FROM city ci
                    INNER JOIN country co ON ci.country_id = co.country_id
                    ORDER BY ci.city_id DESC"; // Ordenado descendente para ver los nuevos

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    con.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            cities.Add(new City
                            {
                                CityId = Convert.ToInt16(reader["city_id"]),
                                CityName = reader["city"].ToString(),
                                CountryId = Convert.ToInt16(reader["country_id"]),
                                CountryName = reader["country"].ToString()
                            });
                        }
                    }
                }
            }
            return View(cities);
        }

        // 2. CREACIÓN (GET)
        public IActionResult Create()
        {
            CargarPaises(); // Cargamos la lista antes de mostrar el formulario
            return View();
        }

        // 3. CREACIÓN (POST)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(City model)
        {
            if (!ModelState.IsValid)
            {
                CargarPaises(); // Si hay error, recargamos la lista
                return View(model);
            }

            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                string query = "INSERT INTO city (city, country_id, last_update) VALUES (@city, @country_id, GETDATE())";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@city", model.CityName);
                    cmd.Parameters.AddWithValue("@country_id", model.CountryId);

                    con.Open();
                    cmd.ExecuteNonQuery();
                }
            }
            return RedirectToAction(nameof(Index));
        }

        // 4. DETALLES (GET) con INNER JOIN
        public IActionResult Details(short? id)
        {
            if (id == null) return NotFound();

            City city = new City();
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                string query = @"
                    SELECT 
                        ci.city_id, 
                        ci.city, 
                        ci.country_id, 
                        co.country 
                    FROM city ci
                    INNER JOIN country co ON ci.country_id = co.country_id
                    WHERE ci.city_id = @id";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    con.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            city.CityId = Convert.ToInt16(reader["city_id"]);
                            city.CityName = reader["city"].ToString();
                            city.CountryId = Convert.ToInt16(reader["country_id"]);
                            city.CountryName = reader["country"].ToString();
                        }
                        else return NotFound();
                    }
                }
            }
            return View(city);
        }

        // 5. EDITAR (GET) con INNER JOIN
        public IActionResult Edit(short? id)
        {
            if (id == null) return NotFound();

            City city = new City();
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                string query = @"
                    SELECT 
                        ci.city_id, 
                        ci.city, 
                        ci.country_id, 
                        co.country 
                    FROM city ci
                    INNER JOIN country co ON ci.country_id = co.country_id
                    WHERE ci.city_id = @id";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    con.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            city.CityId = Convert.ToInt16(reader["city_id"]);
                            city.CityName = reader["city"].ToString();
                            city.CountryId = Convert.ToInt16(reader["country_id"]);
                            city.CountryName = reader["country"].ToString();
                        }
                        else return NotFound();
                    }
                }
            }
            CargarPaises(); // Recargamos la lista de países para el dropdown
            return View(city);
        }

        // 6. EDITAR (POST)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(short id, City model)
        {
            if (id != model.CityId) return NotFound();

            if (!ModelState.IsValid)
            {
                CargarPaises(); // Recargamos la lista si hay error de validación
                return View(model);
            }

            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                string query = "UPDATE city SET city = @city, country_id = @country_id, last_update = GETDATE() WHERE city_id = @id";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@city", model.CityName);
                    cmd.Parameters.AddWithValue("@country_id", model.CountryId);
                    cmd.Parameters.AddWithValue("@id", model.CityId);
                    con.Open();
                    cmd.ExecuteNonQuery();
                }
            }
            return RedirectToAction(nameof(Index));
        }

        // 7. ELIMINAR (GET) con INNER JOIN
        public IActionResult Delete(short? id)
        {
            if (id == null) return NotFound();

            City city = new City();
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                string query = @"
                    SELECT 
                        ci.city_id, 
                        ci.city, 
                        ci.country_id, 
                        co.country 
                    FROM city ci
                    INNER JOIN country co ON ci.country_id = co.country_id
                    WHERE ci.city_id = @id";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    con.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            city.CityId = Convert.ToInt16(reader["city_id"]);
                            city.CityName = reader["city"].ToString();
                            city.CountryId = Convert.ToInt16(reader["country_id"]);
                            city.CountryName = reader["country"].ToString();
                        }
                        else return NotFound();
                    }
                }
            }
            return View(city);
        }

        // 8. ELIMINAR (POST)
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(short id)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    string query = "DELETE FROM city WHERE city_id = @id";
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            catch (SqlException ex)
            {
                // Captura de errores por integridad referencial
                TempData["ErrorMessage"] = "No se pudo eliminar la ciudad. Verifica que no tenga datos asociados.";
                return RedirectToAction(nameof(Delete), new { id = id });
            }
        }
    }
}