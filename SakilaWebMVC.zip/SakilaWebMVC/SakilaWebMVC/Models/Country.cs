﻿using System.ComponentModel.DataAnnotations;

namespace SakilaWebMVC.Models
{
    public class Country
    {
        public short CountryId { get; set; }

        [Required(ErrorMessage = "El nombre del país es obligatorio")]
        [Display(Name = "País")]
        public string CountryName { get; set; } = string.Empty;
    }
}