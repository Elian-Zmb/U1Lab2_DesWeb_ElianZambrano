﻿using System.ComponentModel.DataAnnotations;

namespace SakilaWebMVC.Models
{
    public class City
    {
        public short CityId { get; set; }

        [Required(ErrorMessage = "El nombre de la ciudad es obligatorio")]
        [Display(Name = "Ciudad")]
        public string CityName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Debe seleccionar un país")]
        public short CountryId { get; set; }

        // Propiedad auxiliar exigida por la guía para el INNER JOIN
        [Display(Name = "País")]
        public string CountryName { get; set; } = string.Empty;
    }
}